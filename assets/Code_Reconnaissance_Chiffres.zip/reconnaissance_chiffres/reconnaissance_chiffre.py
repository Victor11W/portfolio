from scipy.io import loadmat
from PIL import Image
import numpy as np
import json
import random
import keyboard
mnist = loadmat("dataset/mnist-original.mat")
mnist_data = mnist["data"].T
mnist_label = mnist["label"][0]

len_a3 = 10
len_a2 = 32
len_a1 = 32
len_a0 = 784


def create_random_lists(n, m):
    assert n > 0, "n doit être un entier positif"
    assert m > 0, "m doit être un entier positif"
    assert type(n) == int, "n doit être un entier"
    assert type(m) == int, "m doit être un entier"
    """
    Crée une liste de n listes, chacune contenant m nombres aléatoires.
    
    Arguments:
    n -- Nombre de listes à créer
    m -- Nombre de nombres aléatoires par liste
    
    Retourne:
    Une liste de n listes, chacune contenant m nombres aléatoires
    """
    random_lists = [np.random.uniform(-1, 1, m).tolist() for _ in range(n)]
    return random_lists

def initialisation():
    coef_1 = create_random_lists(len_a1, len_a0) 
    coef_2 = create_random_lists(len_a2, len_a1)
    coef_3 = create_random_lists(len_a3, len_a2)
    neuronne_1 = np.random.uniform(-1, 1, len_a1)
    neuronne_2 = np.random.uniform(-1, 1, len_a2)
    return coef_1, coef_2, coef_3, neuronne_1, neuronne_2



def sigmoid(x):
    # Limite les valeurs de x pour éviter l'overflow
    x_clipped = np.clip(x, -500, 500)
    return 1 / (1 + np.exp(-x_clipped))

sigmoid_prime = lambda x: sigmoid(x) * (1 - sigmoid(x))

def vague1(list_pixel):
    assert len(list_pixel) == len_a0, "La liste doit être de taille len_a0"
    list_neuronne_1=[]
    for i in range(len_a1):
        valeur=0
        for k in range(len_a0):
            valeur+=list_pixel[k]*coef1[i][k]
        valeur= valeur/255
        valeur+=neu1[i]
        valeur=sigmoid(valeur)
        list_neuronne_1.append(valeur)
    return list_neuronne_1

def vague2(list_neuronne_1):
    assert len(list_neuronne_1) == len_a1, "La liste doit être de taille len_a1"
    list_neuronne_2=[]
    for i in range(len_a2):
        valeur=0
        for k in range(len_a1):
            valeur+=list_neuronne_1[k]*coef2[i][k]
        valeur+=neu2[i]
        valeur=sigmoid(valeur)
        list_neuronne_2.append(valeur)
    return list_neuronne_2

def vague3(list_neuronne_2):
    assert len(list_neuronne_2) == len_a2, "La liste doit être de taille 32"
    list_neuronne_3=[]
    for i in range(len_a3):
        valeur=0
        for k in range(len_a2):
            valeur+=list_neuronne_2[k]*coef3[i][k]
        valeur=sigmoid(valeur)
        list_neuronne_3.append(valeur)

    return list_neuronne_3

def softmax_(x):
    """
    Transforme les valeurs de x en probabilités en utilisant la fonction softmax.
    
    Arguments:
    x -- Liste de coefficients
    
    Retourne:
    Une liste de probabilités
    """
    # Transforme les valeurs de x en probabilités
    shift_x = x - np.max(x)
    e_x = np.exp(shift_x)
    return e_x / np.sum(e_x)

def vague(list_pixel):
    vague1_=vague1(list_pixel)
    vague2_=vague2(vague1_)
    vague3_=vague3(vague2_)
    softmax = softmax_(vague3_)
    return softmax,vague1_,vague2_

def resultat_attendu(indice):
    res=[0,0,0,0,0,0,0,0,0,0]
    res[int(mnist_label[indice])]=1
    return res

def distance_euclidienne(list1, list2):
    assert len(list1) == len(list2), "Les listes doivent être de même taille"
    distance = 0
    for i in range(len(list1)):
        distance += (list1[i] - list2[i]) ** 2
    return distance

def toutes_dérivée_partiel_a(a0,a1,a2,a3):
    #input -> 0, première -> 1, deuxième -> 2, output -> 3
    "a3 est le résultat de la vague"
    "a2 est le résultat de la vague2"
    "a1 est le résultat de la vague1"
    "a0 est l'input"
    C_a0=[]
    C_a1=[]
    C_a2=[]
    C_a3=[]
    for j in range(len_a3):
        C_a3.append((a3[j]-resultat_attendu(indice_image)[j])*2)
    for j in range(len_a2):
        x=0
        for i in range(len_a3):
            x+=C_a3[i] * sigmoid_prime(a3[i]) * coef3[i][j]
        C_a2.append(x)
    for j in range(len_a1):
        x=0
        for i in range(len_a2):
            x+=C_a2[i] * sigmoid_prime(a2[i]) * coef2[i][j]
        C_a1.append(x)
    for j in range(len_a0):
        x=0
        for i in range(len_a1):
            x+=C_a1[i] * sigmoid_prime(a1[i]) * coef1[i][j]
        C_a0.append(x)
    return (C_a0,C_a1,C_a2,C_a3)

def toutes_dérivée_partiel_w(a0,a1,a2,a3,C_a0,C_a1,C_a2,C_a3):
    #input -> 0, première -> 1, deuxième -> 2, output -> 3
    "a3 est le résultat de la vague"
    "a2 est le résultat de la vague2"
    "a1 est le résultat de la vague1"
    "a0 est l'input"
    C_w1 = [[0 for _ in range(len(a0))] for _ in range(len(a1))]
    C_w2 = [[0 for _ in range(len(a1))] for _ in range(len(a2))]
    C_w3 = [[0 for _ in range(len(a2))] for _ in range(len(a3))]
    for i in range(len(a1)):
        for j in range(len(a0)):
            C_w1[i][j]=C_a1[i]*sigmoid_prime(a1[i])*a0[j] #ATTENTION C_W1[I][J] est peut être faux
    for i in range(len(a2)):
        for j in range(len(a1)):
            C_w2[i][j]=C_a2[i]*sigmoid_prime(a2[i])*a1[j] #ATTENTION C_W2[I][J] est peut être faux
    for i in range(len(a3)):
        for j in range(len(a2)):
            C_w3[i][j]=C_a3[i]*sigmoid_prime(a3[i])*a2[j] #ATTENTION C_W3[I][J] est peut être faux
    return (C_w1,C_w2,C_w3)

def toutes_dérivée_partiel_b(a0,a1,a2,a3,C_a0,C_a1,C_a2,C_a3):
    #input -> 0, première -> 1, deuxième -> 2, output -> 3
    "a3 est le résultat de la vague"
    "a2 est le résultat de la vague2"
    "a1 est le résultat de la vague1"
    "a0 est l'input"
    C_b1 = [0 for _ in range(len(a1))]
    C_b2 = [0 for _ in range(len(a2))]
    for i in range(len(a1)):
        C_b1[i]=C_a1[i]*sigmoid_prime(a1[i])
    for i in range(len(a2)):
        C_b2[i]=C_a2[i]*sigmoid_prime(a2[i])
    return (C_b1,C_b2)



def update(finvague1,finvague2,finvague3):
    C_a0,C_a1,C_a2,C_a3=toutes_dérivée_partiel_a(coefficients,finvague1,finvague2,finvague3)
    C_w1,C_w2,C_w3=toutes_dérivée_partiel_w(coefficients,finvague1,finvague2,finvague3,C_a0,C_a1,C_a2,C_a3)
    C_b1,C_b2=toutes_dérivée_partiel_b(coefficients,finvague1,finvague2,finvague3,C_a0,C_a1,C_a2,C_a3)
    for i in range(len(coef1)):
        for j in range(len(coef1[i])):
            coef1[i][j]=coef1[i][j]-0.001*C_w1[i][j]
    for i in range(len(coef2)):
        for j in range(len(coef2[i])):
            coef2[i][j]=coef2[i][j]-0.001*C_w2[i][j]
    for i in range(len(coef3)):
        for j in range(len(coef3[i])):
            coef3[i][j]=coef3[i][j]-0.001*C_w3[i][j]
    for i in range(len(neu1)):
        neu1[i]=neu1[i]-0.1*C_b1[i]
    for i in range(len(neu2)):
        neu2[i]=neu2[i]-0.1*C_b2[i]
    return coef1,coef2,coef3,neu1,neu2


coef1, coef2, coef3, neu1, neu2 = initialisation()
liste = list(range(70000))
# Mélanger la liste
random.shuffle(liste)
# Retourner la liste mélangée
max_= 60000
for i in range(max_):
    indice_image = liste[i]
    coefficients = mnist_data[indice_image]
    resultats, vague1_, vague2_ = vague(coefficients)
    coef1, coef2, coef3, neu1, neu2 = update(vague1_, vague2_, resultats)
    if i % 1000 == 0:
        print(f"Iteration {i} : {distance_euclidienne(resultats, resultat_attendu(indice_image))}")
    if keyboard.is_pressed('q'):
        print("fin de l'entrainement a l'iteration ", i)
        break

    
data = {
    "valeur_restante": liste[max_:],
    "coef1": coef1.tolist() if isinstance(coef1, np.ndarray) else coef1,
    "coef2": coef2.tolist() if isinstance(coef2, np.ndarray) else coef2,
    "coef3": coef3.tolist() if isinstance(coef3, np.ndarray) else coef3,
    "neu1": neu1.tolist() if isinstance(neu1, np.ndarray) else neu1,
    "neu2": neu2.tolist() if isinstance(neu2, np.ndarray) else neu2
}

# Écrire le dictionnaire dans un fichier JSON
with open("data2.json", "w") as file:
    json.dump(data, file, indent=4)