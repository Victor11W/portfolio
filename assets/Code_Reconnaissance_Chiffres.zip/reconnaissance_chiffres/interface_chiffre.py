import pygame
from pygame.locals import *
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
import numpy as np

def interface_chiffre(model, device):
    pygame.init()
    screen = pygame.display.set_mode((280, 320))  # Augmenté en hauteur pour inclure les prédictions
    pygame.display.set_caption("Dessiner un chiffre")
    blanc = (255, 255, 255)
    noir = (0, 0, 0)
    screen.fill(blanc)
    font = pygame.font.Font(None, 30)  # Police pour les prédictions
    running = True
    drawing = False
    pixel_matrice = [[0 for _ in range(28)] for _ in range(28)]

    top3_predictions = []

    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            if event.type == MOUSEBUTTONDOWN:
                drawing = True
            if event.type == MOUSEBUTTONUP:
                drawing = False
            if event.type == MOUSEMOTION:
                if drawing:
                    mouse_x, mouse_y = event.pos
                    if mouse_x < 280 and mouse_y < 280 and mouse_x > 0 and mouse_y > 0:
                        pixel_matrice = dessiner(mouse_x, mouse_y, pixel_matrice)
                        pygame.draw.rect(screen, noir, (mouse_x, mouse_y, 10, 10))
                        
                        # Calculer les prédictions en temps réel
                        top3_predictions = predire(model, device, pixel_matrice)
        
        # Mettre à jour l'écran
        pygame.display.flip()
        
        # Effacer la zone des prédictions
        pygame.draw.rect(screen, blanc, (0, 280, 280, 40))
        
        # Afficher les prédictions
        texte_pred = f"Top 3: {top3_predictions}"
        text_surface = font.render(texte_pred, True, noir)
        screen.blit(text_surface, (10, 285))

    pygame.quit()

def dessiner(x, y, pixel_matrice):
    pixel_matrice[y // 10][x // 10] = 255
    if x > 0:
        pixel_matrice[y // 10][(x - 1) // 10] = 100
    if x < 280:
        pixel_matrice[y // 10][(x + 1) // 10] = 100
    if y > 0:
        pixel_matrice[(y - 1) // 10][x // 10] = 100
    if y < 280:
        pixel_matrice[(y + 1) // 10][x // 10] = 100
    return pixel_matrice

def prepare_image(pixel_matrice):
    image_np = np.array(pixel_matrice, dtype=np.float32)
    image_tensor = torch.tensor(image_np, dtype=torch.float32)
    image_tensor = image_tensor.unsqueeze(0).unsqueeze(0)  # Ajouter les dimensions de batch et de canal
    transform = transforms.Compose([
        transforms.Normalize((0.5,), (0.5,))  # Adaptez si nécessaire
    ])
    image_tensor = transform(image_tensor)
    return image_tensor

def predire(model, device, pixel_matrice):
    # Préparer l'image
    image_tensor = prepare_image(pixel_matrice)
    image_tensor = image_tensor.to(device)

    # Faire la prédiction
    with torch.no_grad():
        outputs = model(image_tensor)
        _, predicted = torch.topk(outputs.data, k=3, dim=1)  # Top 3 prédictions

    # Retourner les indices des classes prédites
    return predicted[0].tolist()

class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.fc1 = nn.Linear(64 * 5 * 5, 128)
        self.fc2 = nn.Linear(128, 10)
    
    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 64 * 5 * 5)  # Flatten
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

def main():
    # Charger le modèle
    model = CNN()
    model.load_state_dict(torch.load('mnist_cnn.pth'))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()

    # Démarrer l'interface
    interface_chiffre(model, device)

if __name__ == "__main__":
    main()
