# Reconnaissance de Chiffres avec Réseaux de Neurones

Ce projet contient deux implémentations d'un modèle de reconnaissance de chiffres utilisant le dataset MNIST. La première implémentation utilise uniquement `numpy`, tandis que la seconde utilise `PyTorch` pour des performances optimisées.
Remarque : j'ai tenté de faire une interface, pour montrer que c'est efficace mais mon interface n'est pas efficace..

## Structure du Projet

- `data.json` : Fichier contenant les paramètres enregistrés du modèle.
- `reco_chiffre2.py` : Script utilisant PyTorch pour une exécution plus rapide.
- `reconnaissance_chiffre.py` : Script utilisant uniquement Numpy.

## Installation des Dépendances

Pour installer toutes les dépendances nécessaires, utilisez le fichier `requirements.txt` avec la commande suivante:

```bash
pip install -r requirements.txt
```

## Utilisation

### reco_chiffre2.py

Ce script utilise PyTorch pour accélérer le processus de reconnaissance des chiffres. Il charge les données du dataset MNIST depuis un fichier `.mat`, entraîne un modèle de réseau de neurones convolutifs (CNN) et évalue sa performance sur les données de test.

### reconnaissance_chiffre.py

Ce script utilise uniquement `numpy` pour implémenter le modèle de reconnaissance des chiffres. Il est moins performant mais peut être utile pour comprendre les fondamentaux des réseaux de neurones.

## Entraînement et Évaluation

1. Chargez et mélangez les données du dataset MNIST.
2. Divisez les données en ensembles d'entraînement et de test.
3. Entraînez le modèle sur les données d'entraînement.
4. Évaluez la performance du modèle sur les données de test.

Pour exécuter un script, utilisez la commande suivante:

```bash
python reco_chiffre2.py
```

ou

Copier le code
```bash
python reconnaissance_chiffre.py
```
## Licence
Ce projet est sous licence MIT.