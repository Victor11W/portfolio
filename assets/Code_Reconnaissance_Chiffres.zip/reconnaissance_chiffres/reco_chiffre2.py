import torch
from scipy.io import loadmat
import numpy as np
import random
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from sklearn.model_selection import train_test_split
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

# Chargement des données
mnist = loadmat("dataset/mnist-original.mat")
mnist_data = mnist["data"].T
mnist_label = mnist["label"][0]

# Préparation des données
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class MNIST_DATASET(Dataset):
    def __init__(self, data, label, transform=None):
        self.data = data
        self.label = label
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        image = self.data[idx].reshape(28, 28)
        label = self.label[idx]
        if self.transform:
            image = self.transform(image)
        return image, label

transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

# Convertir les données en tensors PyTorch
mnist_data_tensor = torch.tensor(mnist_data, dtype=torch.float32)
mnist_labels_tensor = torch.tensor(mnist_label, dtype=torch.long)

# Diviser les indices
train_indices, test_indices = train_test_split(np.arange(len(mnist_data)), test_size=0.2, random_state=42)

# Créer les ensembles d'entraînement et de test
train_data = mnist_data_tensor[train_indices]
train_labels = mnist_labels_tensor[train_indices]
test_data = mnist_data_tensor[test_indices]
test_labels = mnist_labels_tensor[test_indices]

# Créer les datasets PyTorch
train_dataset = MNIST_DATASET(train_data, train_labels, transform=transform)
test_dataset = MNIST_DATASET(test_data, test_labels, transform=transform)

# Création des DataLoaders
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# Définition du modèle CNN
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.fc1 = nn.Linear(64 * 5 * 5, 128)
        self.fc2 = nn.Linear(128, 10)
    
    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 64 * 5 * 5)  # Flatten
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

model = CNN().to(device)

# Définir la fonction de perte et l'optimiseur
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Entraînement du modèle
num_epochs = 10

for epoch in range(num_epochs):
    model.train()  # Met le modèle en mode entraînement
    running_loss = 0.0  # Initialiser la perte cumulative
    
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()  # Réinitialiser les gradients
        
        outputs = model(images)  # Passer les images à travers le modèle
        loss = criterion(outputs, labels)  # Calculer la perte
        loss.backward()  # Calculer les gradients
        optimizer.step()  # Mettre à jour les paramètres du modèle
        
        running_loss += loss.item()  # Accumuler la perte pour cette époque
    
    print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {running_loss/len(train_loader):.4f}')

# Phase d'évaluation
model.eval()  # Met le modèle en mode évaluation
correct = 0  # Initialiser le compteur pour les prédictions correctes
total = 0  # Initialiser le compteur pour le nombre total d'exemples
torch.save(model.state_dict(), "mnist_cnn.pth")

with torch.no_grad():  # Désactiver le calcul des gradients
    for images, labels in test_loader:
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)  # Passer les images à travers le modèle
        _, predicted = torch.max(outputs.data, 1)  # Trouver les indices des valeurs maximales pour les prédictions
        
        total += labels.size(0)  # Accumuler le nombre total d'exemples
        correct += (predicted == labels).sum().item()  # Accumuler le nombre de prédictions correctes

print(f'Accuracy: {100 * correct / total:.2f}%')

